// File: models/index.js

const { sequelize } = require('../config/db');
const User = require('./User');
const Booking = require('./Booking');
const Employee = require('./Employee');
const Payment = require('./Payment');
const Expense = require('./Expense');
const Delivery = require('./Delivery');

// Define Associations (already defined in individual model files but good to have a central view)
// User.hasMany(Booking, { foreignKey: 'userId', as: 'bookings' });
// Booking.belongsTo(User, { foreignKey: 'userId', as: 'customer' });

// Employee.belongsTo(User, { foreignKey: 'userId', as: 'userInfo' }); // One-to-one with User
// User.hasOne(Employee, { foreignKey: 'userId', as: 'employeeInfo' });

// Booking.belongsTo(User, { foreignKey: 'assignedEmployeeId', as: 'assignedEmployee' });

// Booking.hasMany(Payment, { foreignKey: 'bookingId' });
// Payment.belongsTo(Booking, { foreignKey: 'bookingId' });

// Booking.hasOne(Delivery, { foreignKey: 'bookingId' });
// Delivery.belongsTo(Booking, { foreignKey: 'bookingId' });

// Sync all models with the database
const syncModels = async () => {
    try {
        await sequelize.sync({ alter: true }); // `alter: true` will update table if schema changes (use with caution in production)
        console.log('All models were synchronized successfully.');
    } catch (error) {
        console.error('Error syncing models:', error);
    }
};

module.exports = {
    sequelize,
    User,
    Booking,
    Employee,
    Payment,
    Expense,
    Delivery,
    syncModels
};
