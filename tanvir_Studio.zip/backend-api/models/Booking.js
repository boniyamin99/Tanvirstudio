const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');
const User = require('./User'); // Import User model

const Booking = sequelize.define('Booking', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    userId: { // Link to the User who made the booking (if registered)
        type: DataTypes.INTEGER,
        references: {
            model: User,
            key: 'id'
        },
        allowNull: true // Can be null if booking is made by a guest
    },
    clientName: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    clientEmail: {
        type: DataTypes.STRING(100),
        allowNull: false,
        validate: {
            isEmail: true
        }
    },
    clientPhone: {
        type: DataTypes.STRING(20),
        allowNull: true
    },
    serviceType: {
        type: DataTypes.ENUM('recording', 'mixing', 'mastering', 'production', 'instrumentals', 'vocal_training', 'other'),
        allowNull: false
    },
    bookingDate: {
        type: DataTypes.DATEONLY, // YYYY-MM-DD
        allowNull: false
    },
    bookingTime: {
        type: DataTypes.TIME, // HH:MM:SS
        allowNull: false
    },
    message: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    status: {
        type: DataTypes.ENUM(
            'pending',          // প্রাথমিক অবস্থা
            'confirmed',        // পেমেন্টের পর কনফার্মড
            'in_progress',      // কাজ চলছে
            'ready_for_review', // ক্লায়েন্ট রিভিউয়ের জন্য প্রস্তুত
            'completed',        // কাজ সম্পন্ন
            'cancelled'         // বাতিল
        ),
        allowNull: false,
        defaultValue: 'pending'
    },
    assignedEmployeeId: { // Employee assigned to this booking
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: User, // Employees are also users
            key: 'id'
        }
    },
    totalAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.00
    },
    paidAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.00
    },
    dueAmount: {
        type: DataTypes.DECIMAL(10, 2),
        allowNull: false,
        defaultValue: 0.00
    },
    paymentStatus: {
        type: DataTypes.ENUM('unpaid', 'partially_paid', 'paid', 'refunded'),
        allowNull: false,
        defaultValue: 'unpaid'
    },
    invoiceId: { // To store a unique identifier for the generated PDF invoice
        type: DataTypes.STRING,
        allowNull: true
    },
    isFeedbackSurveySent: { // To track if the automated feedback survey has been sent
        type: DataTypes.BOOLEAN,
        defaultValue: false
    }
}, {
    tableName: 'bookings',
    timestamps: true,
    hooks: {
        beforeSave: (booking) => {
            // Automatically calculate dueAmount whenever totalAmount or paidAmount changes
            if (booking.changed('totalAmount') || booking.changed('paidAmount')) {
                booking.dueAmount = booking.totalAmount - booking.paidAmount;
            }
        }
    }
});

// Define associations
Booking.belongsTo(User, { foreignKey: 'userId', as: 'customer' });
Booking.belongsTo(User, { foreignKey: 'assignedEmployeeId', as: 'assignedEmployee' });

module.exports = Booking;
