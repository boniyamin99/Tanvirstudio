const express = require('express');
const http = require('http');
const path = require('path');
const dotenv = require('dotenv');
const cors = require('cors');
const morgan = require('morgan');
const helmet = require('helmet');
const hpp = require('hpp');

// --- Main Application Components ---
const { connectDB } = require('./config/db');
const { syncModels } = require('./models');
const { initializeSocket } = require('./socket');
const initializeJobs = require('./jobs/scheduler');

// --- Import All Application Routes ---
const authRoutes = require('./routes/authRoutes');
const bookingRoutes = require('./routes/bookingRoutes');
const employeeRoutes = require('./routes/employeeRoutes');
const expenseRoutes = require('./routes/expenseRoutes');
const invoiceRoutes = require('./routes/invoiceRoutes');
const logRoutes = require('./routes/logRoutes');
const formRoutes = require('./routes/formRoutes');
const deliveryRoutes = require('./routes/deliveryRoutes');
const reportRoutes = require('./routes/reportRoutes');
const surveyRoutes = require('./routes/surveyRoutes');
const projectRoutes = require('./routes/projectRoutes'); // <-- New route imported

// Load environment variables
dotenv.config();

const app = express();
const server = http.createServer(app);

// Initialize Socket.IO
initializeSocket(server);

// Connect to DB, Sync Models, and Start Jobs
const initializeApp = async () => {
    try {
        await connectDB();
        await syncModels();
        initializeJobs();
    } catch (error) {
        console.error('Failed to initialize application:', error);
        process.exit(1);
    }
};
initializeApp();

// --- Core Middleware ---
app.use(cors());
app.use(express.json());
app.use(helmet());
app.use(hpp());
if (process.env.NODE_ENV === 'development') {
    app.use(morgan('dev'));
}
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// --- API Route Definitions ---
app.use('/api/auth', authRoutes);
app.use('/api/bookings', bookingRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/logs', logRoutes);
app.use('/api/forms', formRoutes);
app.use('/api/deliveries', deliveryRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/surveys', surveyRoutes);
app.use('/api/projects', projectRoutes); // <-- New route used

// ... (Rest of the file)

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
    console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
});
