const { Server } = require('socket.io');

const initializeSocket = (httpServer) => {
    const io = new Server(httpServer, {
        cors: {
            origin: "*", // For development. In production, change to your frontend URL e.g., "http://yourdomain.com"
            methods: ["GET", "POST"]
        }
    });

    // This will run when a new client connects to the server
    io.on('connection', (socket) => {
        console.log(`A user connected: ${socket.id}`);

        // Listen for a 'sendMessage' event from a client
        socket.on('sendMessage', (messageData) => {
            console.log(`Message received from ${socket.id}:`, messageData);
            
            // Broadcast the received message to all other clients
            // In a real app, you might send it to a specific user (e.g., admin)
            socket.broadcast.emit('receiveMessage', messageData);
        });
        
        // This will run when a client disconnects
        socket.on('disconnect', () => {
            console.log(`User disconnected: ${socket.id}`);
        });
    });

    console.log('Socket.IO server initialized.');
};

module.exports = { initializeSocket };
