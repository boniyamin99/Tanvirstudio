const { Booking, User } = require('../models');
// const invoiceService = require('../services/invoiceService'); // Future service for PDF generation
// const jobScheduler = require('../services/jobScheduler'); // Future service for scheduling tasks like surveys

// A dummy price map for calculating total amount. In a real app, this might come from a database table.
const servicePriceMap = {
    recording: 5000,
    mixing: 3500,
    mastering: 2000,
    production: 8000,
    instrumentals: 6000,
    vocal_training: 2500,
    other: 1000, // Base price for 'other'
};

// @desc    Create a new booking with advance payment
// @route   POST /api/bookings
// @access  Public (for website users)
const createBooking = async (req, res) => {
    const {
        clientName,
        clientEmail,
        clientPhone,
        serviceType,
        bookingDate,
        bookingTime,
        message,
        paymentOption // e.g., '40_percent', '50_percent', 'full_payment'
    } = req.body;

    // Basic validation
    if (!clientName || !clientEmail || !serviceType || !bookingDate || !bookingTime || !paymentOption) {
        return res.status(400).json({ message: 'Please fill all required booking and payment fields.' });
    }

    try {
        const totalAmount = servicePriceMap[serviceType] || 0;
        if (totalAmount === 0) {
            return res.status(400).json({ message: 'Invalid service type selected.' });
        }

        let paidAmount = 0;
        if (paymentOption === 'full_payment') {
            paidAmount = totalAmount;
        } else if (paymentOption === '40_percent') {
            paidAmount = totalAmount * 0.40;
        } else if (paymentOption === '50_percent') {
            paidAmount = totalAmount * 0.50;
        } else {
            return res.status(400).json({ message: 'Invalid payment option.' });
        }
        
        const dueAmount = totalAmount - paidAmount;
        const paymentStatus = dueAmount > 0 ? 'partially_paid' : 'paid';
        
        // Create the booking
        const booking = await Booking.create({
            clientName,
            clientEmail,
            clientPhone,
            serviceType,
            bookingDate,
            bookingTime,
            message,
            totalAmount,
            paidAmount,
            dueAmount,
            paymentStatus,
            status: 'confirmed', // Booking is confirmed after initial payment
            userId: req.user ? req.user.id : null,
        });

        // --- PDF Invoice Generation (Placeholder) ---
        // In a real implementation, you would call a service to generate and save the invoice
        // const invoiceId = await invoiceService.generate(booking);
        // await booking.update({ invoiceId: invoiceId });
        // For now, we'll just simulate it
        await booking.update({ invoiceId: `INV-${booking.id}-${Date.now()}` });


        res.status(201).json({
            message: 'Booking confirmed successfully! We will contact you soon.',
            booking,
        });

    } catch (error) {
        console.error('Error creating booking:', error);
        res.status(500).json({ message: 'Server error while creating booking.' });
    }
};

// @desc    Get all bookings (Admin/Manager)
// @route   GET /api/bookings
// @access  Private (admin, manager, accountant)
const getAllBookings = async (req, res) => {
  // This function remains the same, but will now return the new fields from the model
  try {
    const bookings = await Booking.findAll({
      include: [
        { model: User, as: 'customer', attributes: ['username', 'email'] },
      ],
      order: [['bookingDate', 'DESC']],
    });
    res.status(200).json(bookings);
  } catch (error) {
    console.error('Error fetching bookings:', error);
    res.status(500).json({ message: 'Server error while fetching bookings.' });
  }
};


// @desc    Update booking status (Admin/Manager)
// @route   PUT /api/bookings/:id/status
// @access  Private (admin, manager)
const updateBookingStatus = async (req, res) => {
    const { status } = req.body;
    const validStatuses = ['pending', 'confirmed', 'in_progress', 'ready_for_review', 'completed', 'cancelled'];

    if (!status || !validStatuses.includes(status)) {
        return res.status(400).json({ message: 'Invalid status provided.' });
    }

    try {
        const booking = await Booking.findByPk(req.params.id);
        if (!booking) {
            return res.status(404).json({ message: 'Booking not found.' });
        }

        booking.status = status;
        await booking.save();

        // --- Automated Feedback Survey Trigger (Placeholder) ---
        if (status === 'completed' && !booking.isFeedbackSurveySent) {
            // Schedule a job to send a feedback email after 2 days
            // jobScheduler.schedule('send-feedback-email', 'in 2 days', { bookingId: booking.id });
            console.log(`Scheduling feedback survey for booking ID: ${booking.id}`);
        }

        res.status(200).json({
            message: 'Booking status updated successfully!',
            booking,
        });
    } catch (error) {
        console.error('Error updating booking status:', error);
        res.status(500).json({ message: 'Server error while updating booking status.' });
    }
};


// Other functions like getBookingById, assignEmployeeToBooking, deleteBooking remain largely unchanged in structure
// So they are omitted here for brevity, but they should be kept in the actual file.

module.exports = {
  createBooking,
  getAllBookings,
  updateBookingStatus,
  // ... other exported functions (getBookingById, assignEmployeeToBooking, deleteBooking)
};
