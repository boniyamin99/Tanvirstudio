const { User, Employee } = require('../models');
// const { logActivity } = require('../utils/activityLogger'); // A helper function for logging activities

// @desc    Add a new employee (Admin/Manager)
// @route   POST /api/employees
// @access  Private (admin, manager)
const addEmployee = async (req, res) => {
  // Added new fields for shift and leave management
  const { username, password, email, fullName, phoneNumber, position, salary, hireDate, shiftType, hoursPerWeek, availableLeaveDays } = req.body;

  if (!username || !password || !fullName || !position || !salary || !hireDate) {
    return res.status(400).json({ message: 'Please fill all required fields for employee.' });
  }

  try {
    // Create a user record for the employee first
    const user = await User.create({
      username,
      password,
      email,
      fullName,
      phoneNumber,
      role: 'employee',
    });

    // Then create the employee record linked to the user
    const employee = await Employee.create({
      userId: user.id,
      position,
      salary,
      hireDate,
      shiftType,
      hoursPerWeek,
      availableLeaveDays,
    });

    // --- Log Activity (Feature #9) ---
    // await logActivity(req.user.id, 'EMPLOYEE_CREATED', `Created new employee '${fullName}' (ID: ${employee.id})`);

    res.status(201).json({
      message: 'Employee added successfully!',
      employee: {
        id: employee.id,
        fullName: user.fullName,
        username: user.username,
        email: user.email,
        position: employee.position,
      },
    });
  } catch (error) {
    console.error('Error adding employee:', error);
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(400).json({ message: 'Username or email already exists.' });
    }
    res.status(500).json({ message: 'Server error while adding employee.' });
  }
};

// @desc    Update employee details (Admin/Manager)
// @route   PUT /api/employees/:id
// @access  Private (admin, manager)
const updateEmployee = async (req, res) => {
  // Added new updatable fields
  const { username, email, fullName, phoneNumber, position, salary, isActive, shiftType, hoursPerWeek, availableLeaveDays } = req.body;

  try {
    const employee = await Employee.findByPk(req.params.id, {
      include: { model: User, as: 'userInfo' },
    });

    if (!employee) {
      return res.status(404).json({ message: 'Employee not found.' });
    }

    // --- Log what changed (for detailed logging) ---
    const oldData = JSON.stringify(employee);

    // Update User info
    if (employee.userInfo) {
      employee.userInfo.username = username || employee.userInfo.username;
      employee.userInfo.email = email || employee.userInfo.email;
      employee.userInfo.fullName = fullName || employee.userInfo.fullName;
      await employee.userInfo.save();
    }

    // Update Employee specific info
    employee.position = position || employee.position;
    employee.salary = salary || employee.salary;
    employee.isActive = typeof isActive === 'boolean' ? isActive : employee.isActive;
    employee.shiftType = shiftType || employee.shiftType;
    employee.hoursPerWeek = hoursPerWeek || employee.hoursPerWeek;
    employee.availableLeaveDays = availableLeaveDays || employee.availableLeaveDays;

    await employee.save();

    // --- Log Activity (Feature #9) ---
    // await logActivity(req.user.id, 'EMPLOYEE_UPDATED', `Updated details for employee '${employee.userInfo.fullName}' (ID: ${employee.id})`);

    res.status(200).json({
      message: 'Employee updated successfully!',
      employee,
    });
  } catch (error) {
    console.error('Error updating employee:', error);
    res.status(500).json({ message: 'Server error while updating employee.' });
  }
};


// @desc    Delete an employee (Admin)
// @route   DELETE /api/employees/:id
// @access  Private (admin)
const deleteEmployee = async (req, res) => {
  try {
    const employee = await Employee.findByPk(req.params.id, {
      include: { model: User, as: 'userInfo' },
    });

    if (!employee) {
      return res.status(404).json({ message: 'Employee not found.' });
    }

    const employeeName = employee.userInfo.fullName;
    const employeeId = employee.id;

    // Delete the associated user record and employee record
    await employee.userInfo.destroy();
    await employee.destroy();

    // --- Log Activity (Feature #9) ---
    // await logActivity(req.user.id, 'EMPLOYEE_DELETED', `Deleted employee '${employeeName}' (ID: ${employeeId})`);

    res.status(200).json({ message: 'Employee deleted successfully!' });
  } catch (error) {
    console.error('Error deleting employee:', error);
    res.status(500).json({ message: 'Server error while deleting employee.' });
  }
};


// getAllEmployees and getEmployeeById functions remain unchanged in structure.

module.exports = {
  addEmployee,
  updateEmployee,
  deleteEmployee,
  // ...other existing exports (getAllEmployees, getEmployeeById)
};

