const { Booking, User, ProjectMessage, ProjectFile } = require('../models');
// const { getIo } = require('../socket'); 

// ... getProjectDetails and addProjectMessage functions remain the same as before ...
const getProjectDetails = async (req, res) => { /* ... */ };
const addProjectMessage = async (req, res) => { /* ... */ };


// @desc    Upload a file for a specific project
// @route   POST /api/projects/:id/files
// @access  Private (client who owns it, or admin/employee)
const uploadProjectFile = async (req, res) => {
    const bookingId = req.params.id;
    const uploaderId = req.user.id;
    
    if (!req.file) {
        return res.status(400).json({ message: 'No file was uploaded.' });
    }

    try {
        // Determine if the uploader is from the studio or is the client
        const uploadedBy = (req.user.role === 'admin' || req.user.role === 'employee' || req.user.role === 'manager') 
            ? 'studio' 
            : 'client';

        const projectFile = await ProjectFile.create({
            bookingId,
            uploaderId,
            uploadedBy,
            fileName: req.file.originalname,
            filePath: req.file.location, // URL from multer-s3
            fileType: req.file.mimetype,
            fileSize: req.file.size
        });

        // --- Real-time event emission using Socket.IO ---
        // const io = getIo();
        // io.to(`project_${bookingId}`).emit('file_uploaded', projectFile);
        console.log(`Emitting file upload notification to room: project_${bookingId}`);

        res.status(201).json({ message: 'File uploaded successfully!', file: projectFile });

    } catch (error) {
        console.error('Error uploading project file:', error);
        res.status(500).json({ message: 'Server error while uploading file.' });
    }
};


module.exports = {
    getProjectDetails,
    addProjectMessage,
    uploadProjectFile // <-- Export the new function
};
