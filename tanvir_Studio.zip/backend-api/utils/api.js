const BASE_URL = 'http://localhost:5000/api'; // Your backend API base URL

// This is the core request function that handles all API calls
const request = async (endpoint, method = 'GET', body = null) => {
    const headers = new Headers();
    headers.append('Content-Type', 'application/json');

    const token = localStorage.getItem('authToken');
    if (token) {
        headers.append('Authorization', `Bearer ${token}`);
    }

    const config = {
        method,
        headers,
    };

    if (body) {
        config.body = JSON.stringify(body);
    }

    try {
        const response = await fetch(`${BASE_URL}${endpoint}`, config);

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Something went wrong');
        }

        // If response has content, parse it as JSON, otherwise return true for success
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            return await response.json();
        }
        return true; 

    } catch (error) {
        console.error('API request failed:', error);
        throw error; // Re-throw the error to be caught by the calling function
    }
};

// Export simple-to-use helper methods
const api = {
    get: (endpoint) => request(endpoint),
    post: (endpoint, body) => request(endpoint, 'POST', body),
    put: (endpoint, body) => request(endpoint, 'PUT', body),
    del: (endpoint) => request(endpoint, 'DELETE'), // 'delete' is a reserved keyword
};

// Make it available to other scripts (assuming you use a module system or attach to window)
// For simplicity without modules, you can just include this script before others.
