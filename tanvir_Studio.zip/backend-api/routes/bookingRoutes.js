const express = require('express');
const {
    createBooking,
    getAllBookings,
    getBookingById,
    updateBookingStatus,
    assignEmployeeToBooking,
    deleteBooking,
    // --- New controller functions to be created ---
    // addPaymentToBooking, 
    // downloadInvoice 
} = require('../controllers/bookingController');
const { protect, authorizeRoles } = require('../middleware/authMiddleware');

const router = express.Router();

// Public route for creating initial booking and payment
router.route('/')
    .post(createBooking); // This is now the initial booking creation route

// Protected routes for admin/manager/accountant
router.route('/')
    .get(protect, authorizeRoles('admin', 'manager', 'accountant'), getAllBookings);

// Route for downloading an invoice for a booking (Feature #2)
// router.route('/:id/invoice')
//     .get(protect, authorizeRoles('admin', 'manager', 'customer'), downloadInvoice);

// Route for making subsequent payments on a booking (Feature #1)
// router.route('/:id/payment')
//     .post(protect, authorizeRoles('admin', 'customer'), addPaymentToBooking);


router.route('/:id')
    .get(protect, authorizeRoles('admin', 'manager', 'accountant', 'customer'), getBookingById)
    .delete(protect, authorizeRoles('admin'), deleteBooking); // Only admin can delete

router.route('/:id/status')
    .put(protect, authorizeRoles('admin', 'manager'), updateBookingStatus);
    
router.route('/:id/assign')
    .put(protect, authorizeRoles('admin', 'manager'), assignEmployeeToBooking);


module.exports = router;
