const express = require('express');
const {
    addEmployee,
    getAllEmployees,
    getEmployeeById,
    updateEmployee,
    deleteEmployee,
    // --- New controller function to be created ---
    // getEmployeeBookings 
} = require('../controllers/employeeController');
const { protect, authorizeRoles } = require('../middleware/authMiddleware');

const router = express.Router();

// Main routes for adding and getting all employees
router.route('/')
    .post(protect, authorizeRoles('admin', 'manager'), addEmployee)
    .get(protect, authorizeRoles('admin', 'manager', 'accountant'), getAllEmployees);

// New route to get all bookings assigned to a specific employee (for Task Management Board - Feature #5)
// router.route('/:id/bookings')
//     .get(protect, authorizeRoles('admin', 'manager', 'employee'), getEmployeeBookings);

// Routes for a specific employee
router.route('/:id')
    .get(protect, authorizeRoles('admin', 'manager', 'accountant', 'employee'), getEmployeeById)
    .put(protect, authorizeRoles('admin', 'manager'), updateEmployee)
    .delete(protect, authorizeRoles('admin'), deleteEmployee);

module.exports = router;
