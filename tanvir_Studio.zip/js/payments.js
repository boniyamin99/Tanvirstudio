document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const tableBody = document.getElementById('payments-table-body');
    const addNewBtn = document.getElementById('add-manual-payment-btn');
    const modal = document.getElementById('payment-modal');
    const modalCloseBtn = modal.querySelector('.modal-close-btn');
    const modalForm = document.getElementById('modal-payment-form');
    
    // State
    let currentPage = 1;
    let currentFilters = {};

    // --- Core Functions ---

    // Function to fetch and render payments
    const fetchAndRenderPayments = async () => {
        const params = new URLSearchParams({ page: currentPage, ...currentFilters });
        console.log(`Fetching payments from /api/payments?${params.toString()}`);

        // Mock Data for Demonstration
        const mockApiResponse = {
            payments: [
                { id: 1, bookingId: 101, amount: 5000, paymentMethod: 'bKash', transactionId: 'TRX12345ABC', createdAt: '2025-06-10T10:00:00Z', status: 'completed' },
                { id: 2, bookingId: 102, amount: 4000, paymentMethod: 'Cash', transactionId: null, createdAt: '2025-06-12T14:30:00Z', status: 'pending' },
                { id: 3, bookingId: 103, amount: 15000, paymentMethod: 'bank_transfer', transactionId: 'BANK54321', createdAt: '2025-06-15T09:00:00Z', status: 'completed' }
            ],
            totalPages: 4
        };

        tableBody.innerHTML = '';
        mockApiResponse.payments.forEach(payment => {
            const row = document.createElement('tr');
            const statusClass = `status-${payment.status}`;
            
            let actionButton = `<button class="btn-icon view-btn" title="View Details" data-payment-id="${payment.id}"><i class="fas fa-eye"></i></button>`;
            if (payment.status === 'pending') {
                actionButton += `<button class="btn-secondary btn-sm confirm-btn" data-payment-id="${payment.id}">Confirm</button>`;
            }

            row.innerHTML = `
                <td>PAY-${String(payment.id).padStart(3, '0')}</td>
                <td>${payment.bookingId}</td>
                <td>${payment.amount.toLocaleString()}</td>
                <td>${payment.paymentMethod}</td>
                <td>${payment.transactionId || 'N/A'}</td>
                <td>${new Date(payment.createdAt).toLocaleString()}</td>
                <td><span class="status-badge ${statusClass}">${payment.status}</span></td>
                <td class="action-buttons">${actionButton}</td>
            `;
            tableBody.appendChild(row);
        });

        // Update pagination logic here...
    };

    // --- Modal and Form Handling ---
    const openModal = () => {
        modalForm.reset();
        modal.classList.remove('hidden');
    };
    const closeModal = () => modal.classList.add('hidden');

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData(modalForm);
        const data = Object.fromEntries(formData.entries());

        console.log('Submitting manual payment:', data);
        // In real app: await api.post('/payments/manual', data);
        alert('Manual payment logged successfully!');
        closeModal();
        fetchAndRenderPayments();
    };

    // --- Event Listeners ---
    const initializeEventListeners = () => {
        addNewBtn.addEventListener('click', openModal);
        modalCloseBtn.addEventListener('click', closeModal);
        modal.addEventListener('click', e => {
            if (e.target === modal) closeModal();
        });
        modalForm.addEventListener('submit', handleFormSubmit);

        // Event delegation for confirm buttons
        tableBody.addEventListener('click', e => {
            if (e.target.classList.contains('confirm-btn')) {
                const paymentId = e.target.dataset.paymentId;
                if (confirm(`Are you sure you want to confirm payment #${paymentId}?`)) {
                    console.log(`Confirming payment ${paymentId}`);
                    // In real app: await api.put(`/payments/${paymentId}/confirm`);
                    fetchAndRenderPayments();
                }
            }
        });
        
        // Add filter button listener here...
    };


    // --- Initial Load ---
    fetchAndRenderPayments();
    initializeEventListeners();
});
