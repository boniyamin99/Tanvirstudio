document.addEventListener('DOMContentLoaded', () => {
    // State
    let activeConversationId = null;

    // DOM Elements
    const conversationList = document.getElementById('conversation-list');
    const chatPanelPlaceholder = document.getElementById('chat-panel-placeholder');
    const activeChatPanel = document.getElementById('chat-panel-active');
    const chatUsername = document.getElementById('chatting-with-username');
    const messagesContainer = document.getElementById('admin-chat-messages');
    const chatInput = document.getElementById('admin-chat-input');
    const sendBtn = document.getElementById('admin-send-btn');

    // --- Socket.IO Connection ---
    const socket = io("http://localhost:5000");

    socket.on('connect', () => {
        console.log('Admin connected to chat server:', socket.id);
        // Let the server know an admin has joined
        socket.emit('admin_join', { adminId: 'admin_user_1' });
    });

    // --- Core Functions ---

    // Function to render the list of conversations
    const renderConversations = (conversations) => {
        conversationList.innerHTML = '';
        conversations.forEach(convo => {
            const li = document.createElement('li');
            li.className = 'conversation-item';
            li.dataset.userId = convo.id;
            li.innerHTML = `
                <div class="convo-details">
                    <span class="convo-username">${convo.name}</span>
                    <span class="convo-preview">${convo.lastMessage}</span>
                </div>
            `;
            conversationList.appendChild(li);
        });
    };

    // Function to render messages for the active chat
    const renderMessages = (messages) => {
        messagesContainer.innerHTML = '';
        messages.forEach(msg => appendMessage(msg));
    };

    // Helper to append a single message
    const appendMessage = (messageData) => {
        // messageData = { text: "Hello", sender: "user" or "admin" }
        const messageType = messageData.sender === 'admin' ? 'sent' : 'received';
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', messageType);
        messageDiv.textContent = messageData.text;
        messagesContainer.appendChild(messageDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    };


    // --- Event Handlers ---
    
    // 1. Selecting a conversation from the list
    conversationList.addEventListener('click', (e) => {
        const targetItem = e.target.closest('.conversation-item');
        if (!targetItem) return;

        // Update active state
        document.querySelectorAll('.conversation-item').forEach(item => item.classList.remove('active'));
        targetItem.classList.add('active');

        activeConversationId = targetItem.dataset.userId;
        const username = targetItem.querySelector('.convo-username').textContent;
        
        chatUsername.textContent = username;
        chatPanelPlaceholder.classList.add('hidden');
        activeChatPanel.classList.remove('hidden');

        // Fetch and render message history for this conversation
        console.log(`Loading history for ${activeConversationId}`);
        // Mocking history load
        const messageHistory = [
            { text: 'Hello, I have a question.', sender: 'user' },
            { text: 'Hi! How can I help?', sender: 'admin' },
        ];
        renderMessages(messageHistory);
    });

    // 2. Sending a message
    const sendMessage = () => {
        const messageText = chatInput.value.trim();
        if (messageText && activeConversationId) {
            const messageData = {
                text: messageText,
                sender: 'admin',
                recipientId: activeConversationId // Important: Tell server who to send to
            };
            socket.emit('sendMessage', messageData);
            appendMessage(messageData);
            chatInput.value = '';
        }
    };
    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // 3. Receiving a message from a client
    socket.on('receiveMessage', (messageData) => {
        console.log('Message received from a client:', messageData);
        // Here you would update the conversation list (e.g., show unread count)
        // If the message is for the currently active chat, append it
        if (messageData.sender === activeConversationId) {
            appendMessage(messageData);
        }
    });


    // --- Initial Load ---
    const initialLoad = () => {
        // Fetch and render initial conversation list from an API like `/api/chat/conversations`
        const mockConversations = [
            { id: 'user123', name: 'Visitor 123', lastMessage: 'Okay, thank you!' },
            { id: 'user456', name: 'Visitor 456', lastMessage: 'I have a question...' },
        ];
        renderConversations(mockConversations);
    };

    initialLoad();
});
