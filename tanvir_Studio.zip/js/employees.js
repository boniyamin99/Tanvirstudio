document.addEventListener('DOMContentLoaded', () => {
    // State management
    let currentPage = 1;
    let currentFilters = { search: '', status: '', shift: '' };

    // DOM Elements
    const tableBody = document.getElementById('employees-table-body');
    const pageInfo = document.getElementById('page-info');
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    const applyFiltersBtn = document.getElementById('apply-filters-btn');
    const addNewBtn = document.getElementById('add-new-employee-btn');
    const modal = document.getElementById('employee-modal');
    const modalCloseBtn = modal.querySelector('.modal-close-btn');
    const modalForm = document.getElementById('modal-employee-form');
    const modalTitle = document.getElementById('modal-title');

    // Main function to fetch and render employees
    const fetchAndRenderEmployees = async () => {
        const params = new URLSearchParams({ page: currentPage, limit: 10, ...currentFilters });
        console.log(`Fetching from: /api/employees?${params.toString()}`);
        
        // --- Mock Data for Demonstration ---
        // Real data will come from `fetch(`/api/employees?${params.toString()}`)`
        const mockApiResponse = {
            employees: [
                { id: 1, position: 'Sound Engineer', hireDate: '2024-01-15', isActive: true, shiftType: 'morning', availableLeaveDays: 8, userInfo: { id: 101, fullName: 'John Doe', email: 'john.doe@example.com' } },
                { id: 2, position: 'Studio Manager', hireDate: '2023-11-20', isActive: true, shiftType: 'evening', availableLeaveDays: 10, userInfo: { id: 102, fullName: 'Jane Smith', email: 'jane.smith@example.com' } },
                { id: 3, position: 'Vocal Coach', hireDate: '2024-03-01', isActive: false, shiftType: 'flexible', availableLeaveDays: 5, userInfo: { id: 103, fullName: 'Peter Jones', email: 'peter.jones@example.com' } },
            ],
            totalPages: 5,
            currentPage: currentPage
        };
        // --- End Mock Data ---

        tableBody.innerHTML = '';
        mockApiResponse.employees.forEach(employee => {
            const row = document.createElement('tr');
            row.dataset.employeeId = employee.id;
            const statusClass = employee.isActive ? 'status-confirmed' : 'status-cancelled';
            const statusText = employee.isActive ? 'Active' : 'Inactive';

            row.innerHTML = `
                <td>EMP-${String(employee.id).padStart(2, '0')}</td>
                <td>${employee.userInfo.fullName}</td>
                <td>${employee.userInfo.email}</td>
                <td>${employee.position}</td>
                <td>${employee.shiftType.charAt(0).toUpperCase() + employee.shiftType.slice(1)}</td>
                <td>${new Date(employee.hireDate).toLocaleDateString()}</td>
                <td><span class="status-badge ${statusClass}">${statusText}</span></td>
                <td class="action-buttons">
                    <button class="btn-icon edit-btn" title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon btn-danger delete-btn" title="Delete"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        // Update pagination
        pageInfo.textContent = `Page ${mockApiResponse.currentPage} of ${mockApiResponse.totalPages}`;
        prevPageBtn.disabled = mockApiResponse.currentPage <= 1;
        nextPageBtn.disabled = mockApiResponse.currentPage >= mockApiResponse.totalPages;
    };
    
    // --- Modal Handling ---
    const openModalForEdit = async (employeeId) => {
        // Fetch full employee data
        console.log(`Fetching employee ${employeeId} for editing.`);
        // const employeeData = await fetch(`/api/employees/${employeeId}`).then(res => res.json());
        const employeeData = { id: 1, position: 'Sound Engineer', hireDate: '2024-01-15', isActive: true, shiftType: 'morning', availableLeaveDays: 8, salary: 50000, userInfo: { id: 101, fullName: 'John Doe', email: 'john.doe@example.com', username: 'johndoe' }};

        modalTitle.textContent = 'Edit Employee';
        modalForm.querySelector('#employeeId').value = employeeData.id;
        modalForm.querySelector('#fullName').value = employeeData.userInfo.fullName;
        modalForm.querySelector('#email').value = employeeData.userInfo.email;
        modalForm.querySelector('#username').value = employeeData.userInfo.username;
        modalForm.querySelector('#position').value = employeeData.position;
        modalForm.querySelector('#salary').value = employeeData.salary;
        modalForm.querySelector('#hireDate').value = employeeData.hireDate;
        modalForm.querySelector('#shiftType').value = employeeData.shiftType;
        modalForm.querySelector('#availableLeaveDays').value = employeeData.availableLeaveDays;
        modal.classList.remove('hidden');
    };

    const openModalForNew = () => {
        modalTitle.textContent = 'Add New Employee';
        modalForm.reset();
        modalForm.querySelector('#employeeId').value = '';
        modal.classList.remove('hidden');
    };

    const closeModal = () => {
        modal.classList.add('hidden');
    };
    
    const handleFormSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData(modalForm);
        const data = Object.fromEntries(formData.entries());
        const employeeId = data.employeeId;
        
        const method = employeeId ? 'PUT' : 'POST';
        const endpoint = employeeId ? `/api/employees/${employeeId}` : '/api/employees';

        console.log(`Submitting to ${endpoint} with method ${method}`, data);

        // try {
        //     const response = await fetch(endpoint, {
        //         method,
        //         headers: { 'Content-Type': 'application/json' },
        //         body: JSON.stringify(data)
        //     });
        //     if (response.ok) {
        //         closeModal();
        //         fetchAndRenderEmployees(); // Refresh table
        //     } else {
        //         alert('Failed to save employee.');
        //     }
        // } catch (error) {
        //     alert('An error occurred.');
        // }
        
        closeModal(); // For demo
        fetchAndRenderEmployees(); // For demo
    };

    // --- Event Listeners ---
    const initializeEventListeners = () => {
        // Pagination, Filters, etc. (similar to bookings.js)
        
        // Modal Triggers
        addNewBtn.addEventListener('click', openModalForNew);
        modalCloseBtn.addEventListener('click', closeModal);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });

        // Form Submission
        modalForm.addEventListener('submit', handleFormSubmit);

        // Table Action Buttons (Event Delegation)
        tableBody.addEventListener('click', (e) => {
            const editButton = e.target.closest('.edit-btn');
            const deleteButton = e.target.closest('.delete-btn');
            if (editButton) {
                const employeeId = editButton.closest('tr').dataset.employeeId;
                openModalForEdit(employeeId);
            }
            if (deleteButton) {
                // ... (delete logic)
            }
        });
    };

    // --- Initial Load ---
    fetchAndRenderEmployees();
    initializeEventListeners();
});
