document.addEventListener('DOMContentLoaded', () => {
    // --- Get Project ID from URL ---
    const params = new URLSearchParams(window.location.search);
    const projectId = params.get('id');
    
    if (!projectId) {
        document.querySelector('.main-content').innerHTML = '<h2>Project not found. Please provide a valid project ID.</h2>';
        return;
    }

    // --- DOM Elements ---
    const projectTitle = document.getElementById('project-title');
    const projectMessagesContainer = document.getElementById('project-chat-messages');
    const messageInput = document.getElementById('project-message-input');
    const sendMessageBtn = document.getElementById('send-project-message');
    // ... other DOM elements for details, files, etc.

    // --- Socket.IO Connection for Real-time Updates ---
    const socket = io("http://localhost:5000");

    socket.on('connect', () => {
        console.log('Connected to server for project collaboration.');
        // Join a room specific to this project
        socket.emit('join_project_room', { projectId });
    });


    // --- Core Functions ---

    // Function to load all project data
    const loadProjectData = async () => {
        console.log(`Loading all data for project #${projectId}`);
        // In a real app, fetch data from `/api/bookings/${projectId}`
        
        // Mock Data
        const projectData = {
            title: "Mixing for 'New Song'",
            details: { id: 102, clientName: 'Client A', employeeName: 'John Doe', service: 'Mixing', status: 'in_progress', dueDate: 'June 15, 2025' },
            messages: [
                { text: 'Here is the reference track I mentioned.', sender: 'Client A', timestamp: 'June 9, 2025, 10:05 AM' },
                { text: 'Got it! Thanks. I will start working on the mix this afternoon.', sender: 'John Doe (Engineer)', timestamp: 'June 9, 2025, 10:15 AM' }
            ],
            files: {
                studio: [{ name: 'Mix_Draft_v1.wav', date: 'June 9, 2025' }],
                client: [{ name: 'reference_track.mp3', date: 'June 9, 2025' }]
            }
        };

        // Populate the page with data
        projectTitle.textContent = `Project Details: ${projectData.title}`;
        document.getElementById('detail-booking-id').textContent = `#${projectData.details.id}`;
        // ... populate other detail fields

        // Render messages
        projectMessagesContainer.innerHTML = '';
        projectData.messages.forEach(msg => appendMessage(msg));
    };

    // Helper to add a message to the chat window
    const appendMessage = (message) => {
        const messageDiv = document.createElement('div');
        // Simple check to differentiate message origin
        const messageType = message.sender.includes('Engineer') ? 'sent' : 'received';
        messageDiv.classList.add('message', messageType);
        messageDiv.innerHTML = `
            <strong>${message.sender}:</strong> ${message.text}
            <span class="timestamp">${message.timestamp}</span>
        `;
        projectMessagesContainer.appendChild(messageDiv);
        projectMessagesContainer.scrollTop = projectMessagesContainer.scrollHeight;
    };


    // --- Event Handlers ---

    // Send a new message
    sendMessageBtn.addEventListener('click', () => {
        const messageText = messageInput.value.trim();
        if (messageText) {
            const messageData = {
                projectId,
                text: messageText,
                sender: 'John Doe (Engineer)', // This would be dynamic based on logged in user
                timestamp: new Date().toLocaleString()
            };
            // Send message to the server via WebSocket
            socket.emit('send_project_message', messageData);
            
            // Add message to the UI immediately
            appendMessage(messageData);
            messageInput.value = '';
        }
    });

    // Listen for new messages from the server
    socket.on('receive_project_message', (messageData) => {
        console.log('New project message received:', messageData);
        // Append the new message if it's for the current project
        if (messageData.projectId == projectId) {
            appendMessage(messageData);
        }
    });

    // Placeholder for file upload logic
    // ...

    // --- Initial Load ---
    loadProjectData();

});
