document.addEventListener('DOMContentLoaded', () => {

    // DOM Elements
    const welcomeMessage = document.getElementById('welcome-message');
    const activeProjectsCount = document.getElementById('active-projects-count');
    const completedProjectsCount = document.getElementById('completed-projects-count');
    const totalSpent = document.getElementById('total-spent');
    const amountDue = document.getElementById('amount-due');
    const bookingsTableBody = document.getElementById('client-bookings-table');
    const logoutBtn = document.getElementById('client-logout-btn');

    // Main function to load all dashboard data
    const loadDashboardData = async () => {
        // In a real app, you would get the auth token from localStorage
        const token = localStorage.getItem('authToken');
        
        // If no token, redirect to login page
        if (!token) {
            // window.location.href = './index.html'; 
            console.log('User not logged in. Redirecting...');
            return;
        }

        try {
            // Fetch user profile, summary stats, and bookings in parallel
            // For now, we use mock data.
            console.log('Fetching all dashboard data for the client...');

            // Mock Data
            const userProfile = { fullName: 'Client A' };
            const summary = { active: 2, completed: 5, spent: 45000, due: 3000 };
            const bookings = [
                { id: 105, serviceType: 'Production', bookingDate: '2025-07-01', totalAmount: 15000, status: 'confirmed', dueAmount: 6000 },
                { id: 104, serviceType: 'Recording', bookingDate: '2025-06-20', totalAmount: 8000, status: 'in_progress', dueAmount: 0 },
                { id: 101, serviceType: 'Mixing', bookingDate: '2025-06-10', totalAmount: 5000, status: 'completed', dueAmount: 0, deliveryPath: '#' }
            ];

            // 1. Populate Welcome Message and Summary Cards
            welcomeMessage.textContent = `Welcome, ${userProfile.fullName}!`;
            activeProjectsCount.textContent = summary.active;
            completedProjectsCount.textContent = summary.completed;
            totalSpent.textContent = `৳${summary.spent.toLocaleString()}`;
            amountDue.textContent = `৳${summary.due.toLocaleString()}`;

            // 2. Populate Bookings Table
            bookingsTableBody.innerHTML = ''; // Clear existing rows
            bookings.forEach(booking => {
                const row = document.createElement('tr');
                let actionsHtml = '';

                // Conditional Action Buttons
                if (booking.dueAmount > 0) {
                    actionsHtml += `<button class="btn-secondary btn-sm make-payment-btn" data-booking-id="${booking.id}">Make Payment (৳${booking.dueAmount})</button>`;
                }
                if (booking.status === 'completed' && booking.deliveryPath) {
                    actionsHtml += `<button class="btn-secondary btn-sm download-btn" data-download-url="${booking.deliveryPath}"><i class="fas fa-download"></i> Download Files</button>`;
                }
                 actionsHtml += `<button class="btn-secondary btn-sm chat-btn" data-booking-id="${booking.id}"><i class="fas fa-comments"></i> Chat</button>`;


                row.innerHTML = `
                    <td>#${booking.id}</td>
                    <td>${booking.serviceType}</td>
                    <td>${new Date(booking.bookingDate).toLocaleDateString()}</td>
                    <td>৳${booking.totalAmount.toLocaleString()}</td>
                    <td><span class="status-badge status-${booking.status}">${booking.status.replace('_', ' ')}</span></td>
                    <td class="action-buttons">${actionsHtml}</td>
                `;
                bookingsTableBody.appendChild(row);
            });

        } catch (error) {
            console.error('Failed to load dashboard data:', error);
            // Handle error, maybe show a message to the user
        }
    };

    // --- Logout Functionality ---
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            localStorage.removeItem('authToken');
            window.location.href = './index.html';
        });
    }

    // --- Initial Load ---
    loadDashboardData();
});
