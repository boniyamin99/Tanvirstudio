// File: js/admin.js

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('admin-login-form');
    const loginMessage = document.getElementById('login-message');

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = loginForm.username.value;
        const password = loginForm.password.value;

        // In a real application, you would send this to your backend API for authentication
        // For now, we'll use a dummy check for demonstration
        if (username === 'admin' && password === 'admin123') { // Dummy credentials
            loginMessage.textContent = 'Login successful! Redirecting...';
            loginMessage.style.color = 'green';
            // Simulate redirection to admin dashboard
            setTimeout(() => {
                window.location.href = './dashboard.html'; // Redirect to a dummy dashboard page
            }, 1000);
        } else {
            loginMessage.textContent = 'Invalid username or password.';
            loginMessage.style.color = 'red';
        }

        // --- Real API call example (uncomment and replace with your backend endpoint) ---
        // try {
        //     const response = await fetch('/api/admin/login', { // Your backend login API endpoint
        //         method: 'POST',
        //         headers: {
        //             'Content-Type': 'application/json'
        //         },
        //         body: JSON.stringify({ username, password })
        //     });
        //
        //     const data = await response.json();
        //
        //     if (response.ok) {
        //         localStorage.setItem('authToken', data.token); // Save token for future requests
        //         loginMessage.textContent = 'Login successful! Redirecting...';
        //         loginMessage.style.color = 'green';
        //         // Redirect based on role or to a default dashboard
        //         setTimeout(() => {
        //             window.location.href = './dashboard.html';
        //         }, 1000);
        //     } else {
        //         loginMessage.textContent = data.message || 'Login failed.';
        //         loginMessage.style.color = 'red';
        //     }
        // } catch (error) {
        //     console.error('Login error:', error);
        //     loginMessage.textContent = 'An error occurred during login. Please try again.';
        //     loginMessage.style.color = 'red';
        // }
    });
});