document.addEventListener('DOMContentLoaded', () => {
    // --- আপনার দেওয়া মূল কোড ---
    // Header Scroll Effect
    const mainHeader = document.getElementById('main-header');
    if (mainHeader) {
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 50) {
                mainHeader.classList.add('header-scrolled');
            } else {
                mainHeader.classList.remove('header-scrolled');
            }
        });
    }

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);

            if (targetElement) {
                const headerElement = document.querySelector('header#main-header');
                let headerOffset = 70;
                if (headerElement) {
                    headerOffset = headerElement.offsetHeight;
                }
                const elementPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
                const offsetPosition = elementPosition - headerOffset - 20;
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });

    // Scroll animation for sections
    const sections = document.querySelectorAll('section');
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };
    const observer = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
            }
        });
    }, observerOptions);
    sections.forEach(section => {
        observer.observe(section);
    });

    // JavaScript-driven Parallax Effect for Hero Section
    const parallaxBgElement = document.querySelector('.parallax-bg');
    if (parallaxBgElement) {
        window.addEventListener('scroll', function() {
            const scrollPosition = window.pageYOffset;
            const parallaxSpeed = 0.4;
            parallaxBgElement.style.backgroundPositionY = (scrollPosition * parallaxSpeed) + 'px';
        });
    }

    // Lightbox functionality for Portfolio
    const portfolioItems = document.querySelectorAll('.portfolio-item');
    const lightboxOverlay = document.querySelector('.lightbox-overlay');
    const lightboxClose = document.querySelector('.lightbox-close');
    const lightboxImage = document.getElementById('lightbox-image');
    const lightboxAudio = document.getElementById('lightbox-audio');
    const lightboxTitle = document.getElementById('lightbox-title');
    const lightboxDescription = document.getElementById('lightbox-description');

    if (lightboxOverlay && lightboxClose && lightboxImage && lightboxAudio && lightboxTitle && lightboxDescription) {
        portfolioItems.forEach(item => {
            item.addEventListener('click', () => {
                lightboxImage.src = item.dataset.image || "";
                lightboxTitle.textContent = item.dataset.title || "";
                lightboxDescription.textContent = item.dataset.description || "";
                if (item.dataset.audio) {
                    lightboxAudio.src = item.dataset.audio;
                    lightboxAudio.style.display = 'block';
                    lightboxAudio.load();
                } else {
                    lightboxAudio.style.display = 'none';
                    lightboxAudio.pause();
                    lightboxAudio.removeAttribute('src');
                }
                lightboxOverlay.classList.add('active');
            });
        });

        const closeLightbox = () => {
            lightboxOverlay.classList.remove('active');
            if (lightboxAudio) lightboxAudio.pause();
        };
        lightboxClose.addEventListener('click', closeLightbox);
        lightboxOverlay.addEventListener('click', (e) => {
            if (e.target === lightboxOverlay) closeLightbox();
        });
    }
    // --- আপনার মূল কোডের শেষ অংশ ---


    // --- নতুন যোগ করা কোড ---

    // 1. Booking Form Payment Calculation Logic
    const packageSelect = document.getElementById('package');
    const paymentOptionRadios = document.querySelectorAll('input[name="paymentOption"]');
    const payableAmountSpan = document.getElementById('payable-amount');

    const updatePaymentSummary = () => {
        if (!packageSelect || !payableAmountSpan) return;
        const selectedOption = packageSelect.options[packageSelect.selectedIndex];
        const price = parseFloat(selectedOption.dataset.price) || 0;
        let payableAmount = 0;
        const selectedPaymentOption = document.querySelector('input[name="paymentOption"]:checked')?.value;
        if (price > 0 && selectedPaymentOption) {
            if (selectedPaymentOption === 'full_payment') payableAmount = price;
            else if (selectedPaymentOption === '50_percent') payableAmount = price * 0.50;
            else if (selectedPaymentOption === '40_percent') payableAmount = price * 0.40;
        }
        payableAmountSpan.textContent = `৳${payableAmount.toLocaleString()}`;
    };
    if (packageSelect) {
        packageSelect.addEventListener('change', updatePaymentSummary);
        paymentOptionRadios.forEach(radio => radio.addEventListener('change', updatePaymentSummary));
    }

    // 2. Updated Booking Form Submission Logic (Replaces original simple version)
    const bookingForm = document.getElementById('booking-form');
    const bookingMessage = document.getElementById('booking-message');
    if (bookingForm) {
        bookingForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const submitButton = bookingForm.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.textContent = 'Processing...';

            const formData = new FormData(bookingForm);
            const data = Object.fromEntries(formData.entries());
            data.serviceType = data.package;

            try {
                const response = await fetch('/api/bookings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await response.json();
                if (response.ok) {
                    bookingMessage.textContent = result.message || 'Booking Confirmed!';
                    bookingMessage.style.color = 'green';
                    bookingForm.reset();
                    updatePaymentSummary();
                } else {
                    bookingMessage.textContent = result.message || 'Booking failed.';
                    bookingMessage.style.color = 'red';
                }
            } catch (error) {
                bookingMessage.textContent = 'An error occurred. Please check your connection.';
                bookingMessage.style.color = 'red';
            } finally {
                submitButton.disabled = false;
                submitButton.textContent = 'Confirm Booking & Pay';
            }
        });
    }

    // 3. Live Chat Widget Logic
    try {
        const socket = io("http://localhost:5000"); // Your backend URL
        const chatBubble = document.getElementById('chat-bubble');
        const chatWindow = document.getElementById('chat-window');
        if (chatBubble && chatWindow) {
            const closeChatBtn = document.getElementById('close-chat-btn');
            const chatInput = document.getElementById('chat-input');
            const sendChatBtn = document.getElementById('send-chat-btn');
            const chatMessages = document.getElementById('chat-messages');

            chatBubble.addEventListener('click', () => chatWindow.classList.toggle('hidden'));
            closeChatBtn.addEventListener('click', () => chatWindow.classList.add('hidden'));
            
            const appendMessage = (data) => {
                 const div = document.createElement('div');
                 div.classList.add('message', data.sender === 'user' ? 'sent' : 'received');
                 div.textContent = data.text;
                 chatMessages.appendChild(div);
                 chatMessages.scrollTop = chatMessages.scrollHeight;
            };

            const sendMessage = () => {
                const text = chatInput.value.trim();
                if (text) {
                    const messageData = { text, sender: 'user' };
                    socket.emit('sendMessage', messageData);
                    appendMessage(messageData);
                    chatInput.value = '';
                }
            };

            sendChatBtn.addEventListener('click', sendMessage);
            chatInput.addEventListener('keypress', (e) => {
                if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
            });
            socket.on('receiveMessage', (data) => appendMessage(data));
        }
    } catch (e) {
        console.error("Socket.IO client could not be loaded. Live chat is disabled.");
    }

    // 4. PWA Service Worker Registration
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('/sw.js')
                .then(reg => console.log('Service Worker registered successfully.'))
                .catch(err => console.error('Service Worker registration failed:', err));
        });
    }
});
