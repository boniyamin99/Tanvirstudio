document.addEventListener('DOMContentLoaded', () => {
    
    // --- Function to Fetch Dashboard Stats (Feature #3) ---
    const fetchDashboardStats = async () => {
        // In a real app, you'd fetch this from an API endpoint like '/api/reports/summary'
        const stats = {
            totalBookings: 135,
            totalRevenue: 95000,
            totalExpenses: 25000,
            netProfit: 70000,
        };
        document.getElementById('total-bookings').textContent = stats.totalBookings;
        document.getElementById('total-revenue').textContent = `৳${stats.totalRevenue.toLocaleString()}`;
        document.getElementById('total-expenses').textContent = `৳${stats.totalExpenses.toLocaleString()}`;
        document.getElementById('net-profit').textContent = `৳${stats.netProfit.toLocaleString()}`;
    };

    // --- Function to Render the Kanban Board (Feature #5) ---
    const renderKanbanBoard = async () => {
        // Fetch bookings from '/api/bookings'
        const bookings = [
            { id: 1, clientName: 'Client A - Mixing', status: 'confirmed' },
            { id: 2, clientName: 'Client B - Recording', status: 'in_progress' },
            { id: 3, clientName: 'Client C - Production', status: 'ready_for_review' },
            { id: 4, clientName: 'Client D - Mastering', status: 'in_progress' },
            { id: 5, clientName: 'Client E - Vocal Training', status: 'confirmed' },
        ];

        const columns = {
            confirmed: document.getElementById('col-confirmed'),
            in_progress: document.getElementById('col-in-progress'),
            ready_for_review: document.getElementById('col-ready-for-review'),
            completed: document.getElementById('col-completed'),
        };

        // Clear existing cards
        Object.values(columns).forEach(col => {
            if(col) col.innerHTML = `<h4>${col.querySelector('h4').textContent}</h4>`;
        });

        bookings.forEach(booking => {
            const card = document.createElement('div');
            card.className = 'kanban-card';
            card.draggable = true;
            card.textContent = booking.clientName;
            card.dataset.bookingId = booking.id;

            const columnKey = booking.status.replace(/ /g, '_');
            if (columns[columnKey]) {
                columns[columnKey].appendChild(card);
            }
        });

        addDragAndDropListeners();
    };

    // --- Drag and Drop for Kanban Board ---
    const addDragAndDropListeners = () => {
        const cards = document.querySelectorAll('.kanban-card');
        const columns = document.querySelectorAll('.kanban-column');

        cards.forEach(card => {
            card.addEventListener('dragstart', () => {
                card.classList.add('dragging');
            });
            card.addEventListener('dragend', () => {
                card.classList.remove('dragging');
            });
        });

        columns.forEach(column => {
            column.addEventListener('dragover', e => {
                e.preventDefault();
                const draggingCard = document.querySelector('.dragging');
                column.appendChild(draggingCard);
            });

            column.addEventListener('drop', e => {
                e.preventDefault();
                const card = document.querySelector('.dragging');
                const newStatus = column.id.replace('col-', '');
                const bookingId = card.dataset.bookingId;
                
                // --- API call to update status ---
                console.log(`Booking ID ${bookingId} status changed to ${newStatus}`);
                // fetch(`/api/bookings/${bookingId}/status`, {
                //     method: 'PUT',
                //     headers: { 'Content-Type': 'application/json' },
                //     body: JSON.stringify({ status: newStatus })
                // });
            });
        });
    };

    // --- Function to Fetch Activity Logs (Feature #9) ---
    const fetchActivityLogs = async () => {
        const logList = document.getElementById('activity-log-list');
        // Fetch logs from '/api/logs?limit=5'
        const logs = [
            { text: "Admin updated booking #101 to 'Completed'" },
            { text: "New expense of ৳5,000 recorded for 'Equipment'" },
            { text: "Client F confirmed a new booking." },
            { text: "Employee Jane Smith logged in." },
        ];
        logList.innerHTML = '';
        logs.forEach(log => {
            const li = document.createElement('li');
            li.textContent = log.text;
            logList.appendChild(li);
        });
    };

    // --- Function to Fetch On-Shift Employees (Feature #11) ---
    const fetchOnShiftEmployees = async () => {
        const shiftList = document.getElementById('on-shift-list');
        // Fetch from '/api/employees?onShift=today'
        const employees = [
            { name: 'John Doe', shift: 'Morning' },
            { name: 'Jane Smith', shift: 'Evening' },
            { name: 'Peter Jones', shift: 'Morning' },
        ];
        shiftList.innerHTML = '';
        employees.forEach(emp => {
            const li = document.createElement('li');
            li.textContent = `${emp.name} (${emp.shift})`;
            shiftList.appendChild(li);
        });
    };

    // --- Chart Initialization (Now with Fetched Data) ---
    const initializeCharts = async () => {
        // Fetch chart data from API endpoints like '/api/reports/monthly-income'
        const monthlyIncomeCtx = document.getElementById('monthlyIncomeChart')?.getContext('2d');
        if (monthlyIncomeCtx) {
            // ... (Chart.js code for monthly income chart, using fetched data)
        }

        const serviceBookingsCtx = document.getElementById('serviceBookingsChart')?.getContext('2d');
         if (serviceBookingsCtx) {
            // ... (Chart.js code for service bookings chart, using fetched data)
        }
    };


    // --- Initial Load ---
    fetchDashboardStats();
    renderKanbanBoard();
    fetchActivityLogs();
    fetchOnShiftEmployees();
    // initializeCharts(); // You can enable this when you have the chart APIs
});

