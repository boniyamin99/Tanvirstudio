document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const generateBtn = document.getElementById('generate-report-btn');
    const startDateInput = document.getElementById('start-date');
    const endDateInput = document.getElementById('end-date');

    const summaryCards = document.getElementById('report-summary-cards');
    const detailsArea = document.getElementById('report-details-area');
    
    const revenueCardValue = document.getElementById('report-total-revenue');
    const expensesCardValue = document.getElementById('report-total-expenses');
    const profitCardValue = document.getElementById('report-net-profit');
    
    const expenseTableBody = document.getElementById('expense-breakdown-table');
    const pnlChartCanvas = document.getElementById('pnlChart').getContext('2d');
    const expensePieChartCanvas = document.getElementById('expensePieChart').getContext('2d');
    
    let pnlChartInstance = null;
    let expensePieChartInstance = null;

    // --- Function to fetch and render the report ---
    const generateReport = async () => {
        const startDate = startDateInput.value;
        const endDate = endDateInput.value;

        if (!startDate || !endDate) {
            alert('Please select both a start and end date.');
            return;
        }

        generateBtn.disabled = true;
        generateBtn.textContent = 'Generating...';

        try {
            const params = new URLSearchParams({ startDate, endDate });
            console.log(`Fetching report from /api/reports/profit-loss?${params.toString()}`);
            
            // Mock API response for demonstration
            const reportData = {
                totalRevenue: 75000,
                totalExpenses: 22000,
                netProfit: 53000,
                expenseBreakdown: [
                    { category: 'salaries', total_amount: '15000' },
                    { category: 'equipment', total_amount: '5000' },
                    { category: 'marketing', total_amount: '2000' },
                ]
            };
            // In a real app, you would use:
            // const reportData = await fetch(`/api/reports/profit-loss?${params.toString()}`).then(res => res.json());

            // 1. Populate Summary Cards
            revenueCardValue.textContent = `৳${reportData.totalRevenue.toLocaleString()}`;
            expensesCardValue.textContent = `৳${reportData.totalExpenses.toLocaleString()}`;
            profitCardValue.textContent = `৳${reportData.netProfit.toLocaleString()}`;

            // 2. Populate Expense Breakdown Table
            expenseTableBody.innerHTML = '';
            reportData.expenseBreakdown.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.category.charAt(0).toUpperCase() + item.category.slice(1)}</td>
                    <td>${parseFloat(item.total_amount).toLocaleString()}</td>
                `;
                expenseTableBody.appendChild(row);
            });

            // 3. Render Charts
            renderPnlChart(reportData);
            renderExpensePieChart(reportData.expenseBreakdown);

            // 4. Show the report sections
            summaryCards.classList.remove('hidden');
            detailsArea.classList.remove('hidden');

        } catch (error) {
            console.error('Failed to generate report:', error);
            alert('Could not generate the report. Please try again.');
        } finally {
            generateBtn.disabled = false;
            generateBtn.textContent = 'Generate Report';
        }
    };
    
    // --- Chart Rendering Functions ---
    const renderPnlChart = (reportData) => {
        if(pnlChartInstance) {
            pnlChartInstance.destroy(); // Destroy old chart before creating new one
        }
        pnlChartInstance = new Chart(pnlChartCanvas, {
            type: 'bar',
            data: {
                labels: ['Financials'],
                datasets: [
                    { label: 'Total Revenue', data: [reportData.totalRevenue], backgroundColor: 'rgba(75, 192, 192, 0.6)' },
                    { label: 'Total Expenses', data: [reportData.totalExpenses], backgroundColor: 'rgba(255, 99, 132, 0.6)' },
                    { label: 'Net Profit', data: [reportData.netProfit], backgroundColor: 'rgba(54, 162, 235, 0.6)' }
                ]
            }
        });
    };

    const renderExpensePieChart = (expenseData) => {
        if(expensePieChartInstance) {
            expensePieChartInstance.destroy();
        }
        expensePieChartInstance = new Chart(expensePieChartCanvas, {
            type: 'pie',
            data: {
                labels: expenseData.map(item => item.category.charAt(0).toUpperCase() + item.category.slice(1)),
                datasets: [{
                    data: expenseData.map(item => item.total_amount),
                    backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40']
                }]
            }
        });
    };

    // --- Event Listener ---
    generateBtn.addEventListener('click', generateReport);
});
