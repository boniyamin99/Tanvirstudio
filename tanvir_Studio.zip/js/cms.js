document.addEventListener('DOMContentLoaded', () => {
    const cmsForm = document.getElementById('cms-form');
    const saveButton = document.getElementById('save-all-cms-changes');

    // --- Function to load existing content into the form ---
    const loadContentData = async () => {
        try {
            console.log('Fetching website content...');
            // In a real app, you would fetch from a backend endpoint like '/api/content'
            // const response = await fetch('/api/content');
            // const data = await response.json();

            // Mock data for demonstration
            const mockData = {
                hero_title: "Create Your Sound",
                hero_subtitle: "Unleash your creativity with our state-of-the-art recording studio!",
                about_us_text: "Established in 20XX, our professional music studio is dedicated...",
                service_recording: "High-fidelity audio recording with state-of-the-art equipment.",
                service_mixing: "Perfect your tracks with professional mixing.",
                service_mastering: "Polish your music for release-ready sound.",
                contact_location: "123 Music Lane, Studio City, Melodyville, 45678",
                contact_phone: "+1 (234) 567-890",
                contact_email: "info@musicstudio.com"
            };
            
            // Populate the form with the fetched data
            for (const key in mockData) {
                if (document.getElementById(key.replace(/_/g, '-'))) {
                    document.getElementById(key.replace(/_/g, '-')).value = mockData[key];
                }
            }

        } catch (error) {
            console.error('Failed to load content:', error);
            alert('Could not load website content. Please try again.');
        }
    };

    // --- Function to handle saving all changes ---
    const handleSaveChanges = async (e) => {
        e.preventDefault();
        saveButton.disabled = true;
        saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

        const formData = new FormData(cmsForm);
        const data = Object.fromEntries(formData.entries());

        try {
            console.log('Saving content data:', data);
            // In a real app, you would send a PUT request to update the content
            // const response = await fetch('/api/content', {
            //     method: 'PUT',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(data)
            // });

            // if (!response.ok) {
            //     throw new Error('Failed to save changes.');
            // }

            // Simulating success
            setTimeout(() => {
                alert('Website content updated successfully!');
            }, 1000);

        } catch (error) {
            console.error('Failed to save content:', error);
            alert('An error occurred while saving. Please try again.');
        } finally {
            saveButton.disabled = false;
            saveButton.innerHTML = '<i class="fas fa-save"></i> Save All Changes';
        }
    };

    // --- Event Listeners ---
    saveButton.addEventListener('click', handleSaveChanges);

    // --- Initial Load ---
    loadContentData();
});
