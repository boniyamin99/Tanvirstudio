document.addEventListener('DOMContentLoaded', () => {
    // State management
    let currentPage = 1;
    let currentFilters = {
        userId: '',
        actionType: '',
        startDate: '',
        endDate: ''
    };

    // DOM Elements
    const tableBody = document.getElementById('logs-table-body');
    const pageInfo = document.getElementById('page-info');
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    const applyFiltersBtn = document.getElementById('apply-filters-btn');
    const userFilter = document.getElementById('user-filter');

    // Function to populate the user filter dropdown
    const populateUserFilter = async () => {
        // In a real app, fetch users from `/api/users`
        const users = [
            { id: 1, username: 'admin' },
            { id: 101, username: 'johndoe' },
            { id: 102, username: 'janesmith' }
        ];

        users.forEach(user => {
            const option = document.createElement('option');
            option.value = user.id;
            option.textContent = user.username;
            userFilter.appendChild(option);
        });
    };

    // Main function to fetch and render logs
    const fetchAndRenderLogs = async () => {
        const params = new URLSearchParams({
            page: currentPage,
            limit: 15,
            ...currentFilters
        });
        console.log(`Fetching logs from: /api/logs?${params.toString()}`);

        // Mock API Response
        const mockApiResponse = {
            totalItems: 3,
            totalPages: 1,
            currentPage: 1,
            logs: [
                { id: 1, User: { fullName: 'Admin User' }, actionType: 'EMPLOYEE_CREATED', details: "Created new employee 'John Doe' (ID: 1)", ipAddress: '127.0.0.1', createdAt: '2025-06-09T10:30:00Z' },
                { id: 2, User: { fullName: 'John Doe' }, actionType: 'USER_LOGIN', details: "User 'johndoe' logged in successfully.", ipAddress: '192.168.1.5', createdAt: '2025-06-09T11:00:00Z' },
                { id: 3, User: { fullName: 'Admin User' }, actionType: 'BOOKING_CREATED', details: "New booking created for Client C", ipAddress: '127.0.0.1', createdAt: '2025-06-09T11:15:00Z' }
            ]
        };
        // End Mock API Response

        tableBody.innerHTML = ''; // Clear table
        mockApiResponse.logs.forEach(log => {
            const row = document.createElement('tr');
            const formattedDate = new Date(log.createdAt).toLocaleString();
            
            row.innerHTML = `
                <td>${log.User.fullName || 'N/A'}</td>
                <td><span class="status-badge status-info">${log.actionType}</span></td>
                <td>${log.details}</td>
                <td>${log.ipAddress || 'N/A'}</td>
                <td>${formattedDate}</td>
            `;
            tableBody.appendChild(row);
        });
        
        // Update pagination
        pageInfo.textContent = `Page ${mockApiResponse.currentPage} of ${mockApiResponse.totalPages}`;
        prevPageBtn.disabled = mockApiResponse.currentPage <= 1;
        nextPageBtn.disabled = mockApiResponse.currentPage >= mockApiResponse.totalPages;
    };
    
    // --- Event Listeners ---
    const initializeEventListeners = () => {
        // Pagination
        prevPageBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                fetchAndRenderLogs();
            }
        });
        nextPageBtn.addEventListener('click', () => {
            currentPage++;
            fetchAndRenderLogs();
        });

        // Filters
        applyFiltersBtn.addEventListener('click', () => {
            currentFilters.userId = document.getElementById('user-filter').value;
            currentFilters.actionType = document.getElementById('action-type-filter').value;
            currentFilters.startDate = document.getElementById('date-start-filter').value;
            currentFilters.endDate = document.getElementById('date-end-filter').value;
            currentPage = 1; // Reset to first page
            fetchAndRenderLogs();
        });
    };


    // --- Initial Load ---
    populateUserFilter();
    fetchAndRenderLogs();
    initializeEventListeners();
});
