document.addEventListener('DOMContentLoaded', () => {
    // State management variables
    let currentPage = 1;
    let currentFilters = {
        search: '',
        status: '',
        startDate: '',
        endDate: ''
    };

    // DOM Elements
    const tableBody = document.getElementById('bookings-table-body');
    const pageInfo = document.getElementById('page-info');
    const prevPageBtn = document.getElementById('prev-page-btn');
    const nextPageBtn = document.getElementById('next-page-btn');
    const applyFiltersBtn = document.getElementById('apply-filters-btn');
    const searchInput = document.getElementById('search-input');
    const statusFilter = document.getElementById('status-filter');

    // Main function to fetch and render bookings
    const fetchAndRenderBookings = async () => {
        // Construct API URL with query parameters for pagination and filtering
        const params = new URLSearchParams({
            page: currentPage,
            limit: 10, // Show 10 bookings per page
            ...currentFilters
        });
        
        // In a real app, the URL would be `/api/bookings?${params.toString()}`
        console.log(`Fetching data from: /api/bookings?${params.toString()}`);
        
        // --- Mock Data for Demonstration ---
        const mockApiResponse = {
            bookings: [
                { id: 101, clientName: 'Client A', serviceType: 'Mixing', bookingDate: '2025-06-10', totalAmount: 5000, paidAmount: 5000, dueAmount: 0, paymentStatus: 'paid', status: 'completed' },
                { id: 102, clientName: 'Client B', serviceType: 'Recording', bookingDate: '2025-06-12', totalAmount: 8000, paidAmount: 4000, dueAmount: 4000, paymentStatus: 'partially_paid', status: 'in_progress' },
                { id: 103, clientName: 'Client C', serviceType: 'Production', bookingDate: '2025-06-15', totalAmount: 15000, paidAmount: 15000, dueAmount: 0, paymentStatus: 'paid', status: 'confirmed' },
            ],
            totalPages: 10,
            currentPage: currentPage
        };
        // --- End of Mock Data ---

        // Clear existing table rows
        tableBody.innerHTML = '';

        // Render new rows
        mockApiResponse.bookings.forEach(booking => {
            const row = document.createElement('tr');
            row.dataset.bookingId = booking.id;
            
            row.innerHTML = `
                <td>${booking.id}</td>
                <td>${booking.clientName}</td>
                <td>${booking.serviceType}</td>
                <td>${new Date(booking.bookingDate).toLocaleDateString()}</td>
                <td>${booking.totalAmount.toLocaleString()}</td>
                <td>${booking.paidAmount.toLocaleString()}</td>
                <td>${booking.dueAmount.toLocaleString()}</td>
                <td><span class="status-badge status-${booking.paymentStatus}">${booking.paymentStatus.replace('_', ' ')}</span></td>
                <td><span class="status-badge status-${booking.status}">${booking.status.replace('_', ' ')}</span></td>
                <td class="action-buttons">
                    <button class="btn-icon view-btn" title="View Details"><i class="fas fa-eye"></i></button>
                    <button class="btn-icon edit-btn" title="Edit"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon btn-danger delete-btn" title="Delete"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        // Update pagination controls
        pageInfo.textContent = `Page ${mockApiResponse.currentPage} of ${mockApiResponse.totalPages}`;
        prevPageBtn.disabled = mockApiResponse.currentPage <= 1;
        nextPageBtn.disabled = mockApiResponse.currentPage >= mockApiResponse.totalPages;
    };

    // --- Event Listeners Setup ---
    const initializeEventListeners = () => {
        // Pagination
        prevPageBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                fetchAndRenderBookings();
            }
        });

        nextPageBtn.addEventListener('click', () => {
            currentPage++;
            fetchAndRenderBookings();
        });

        // Filters
        applyFiltersBtn.addEventListener('click', () => {
            currentFilters.search = document.getElementById('search-input').value;
            currentFilters.status = document.getElementById('status-filter').value;
            currentFilters.startDate = document.getElementById('date-start-filter').value;
            currentFilters.endDate = document.getElementById('date-end-filter').value;
            currentPage = 1; // Reset to first page on new filter
            fetchAndRenderBookings();
        });
        
        // Action Buttons (using event delegation)
        tableBody.addEventListener('click', (e) => {
            const targetButton = e.target.closest('button');
            if (!targetButton) return;

            const bookingId = targetButton.closest('tr').dataset.bookingId;

            if (targetButton.classList.contains('view-btn')) {
                console.log(`View booking ${bookingId}`);
                // Open a detail modal or page
            } else if (targetButton.classList.contains('edit-btn')) {
                console.log(`Edit booking ${bookingId}`);
                // Open the add/edit modal with pre-filled data
            } else if (targetButton.classList.contains('delete-btn')) {
                console.log(`Delete booking ${bookingId}`);
                if(confirm('Are you sure you want to delete this booking?')) {
                    // Call API to delete
                }
            }
        });
        
        // Modal controls
        // ... (Logic to open/close the #booking-modal)
    };

    // --- Initial Load ---
    fetchAndRenderBookings();
    initializeEventListeners();
});

