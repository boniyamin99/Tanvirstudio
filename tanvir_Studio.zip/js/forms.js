document.addEventListener('DOMContentLoaded', () => {
    // State
    let formFields = [];

    // DOM Elements
    const fieldsListElement = document.getElementById('form-fields-list');
    const addNewBtn = document.getElementById('add-new-field-btn');
    const modal = document.getElementById('field-editor-modal');
    const modalCloseBtn = modal.querySelector('.modal-close-btn');
    const modalForm = document.getElementById('modal-field-form');
    const modalTitle = document.getElementById('modal-title');
    const fieldTypeSelect = document.getElementById('field-type');
    const dropdownOptionsContainer = document.getElementById('dropdown-options-container');

    // --- Core Functions ---

    // Render the list of fields
    const renderFields = () => {
        fieldsListElement.innerHTML = '';
        formFields.forEach(field => {
            const li = document.createElement('li');
            li.className = 'form-field-item';
            li.dataset.fieldId = field.id;
            li.innerHTML = `
                <i class="fas fa-grip-vertical handle"></i>
                <span class="field-label">${field.label}</span>
                <span class="field-type-badge">${field.type}</span>
                <div class="action-buttons">
                    <button class="btn-icon edit-btn"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon btn-danger delete-btn"><i class="fas fa-trash"></i></button>
                </div>
            `;
            fieldsListElement.appendChild(li);
        });
    };

    // Fetch form structure from backend
    const fetchFormStructure = async () => {
        console.log('Fetching form structure...');
        // Mock data, in real app: await fetch('/api/forms/booking-form')
        const mockData = [
            { id: 1, label: 'Your Name', type: 'text', required: true, order: 1 },
            { id: 2, label: 'Email Address', type: 'email', required: true, order: 2 },
            { id: 3, label: 'Your Message', type: 'textarea', required: false, order: 3 },
        ];
        formFields = mockData.sort((a, b) => a.order - b.order);
        renderFields();
    };

    // --- Modal Handling ---
    const openModalForNew = () => {
        modalTitle.textContent = 'Add New Field';
        modalForm.reset();
        modal.classList.remove('hidden');
    };

    const openModalForEdit = (fieldId) => {
        const field = formFields.find(f => f.id == fieldId);
        if (!field) return;

        modalTitle.textContent = 'Edit Field';
        modalForm.querySelector('#fieldId').value = field.id;
        modalForm.querySelector('#field-label').value = field.label;
        modalForm.querySelector('#field-type').value = field.type;
        modalForm.querySelector('#field-required').checked = field.required;
        
        if (field.type === 'select') {
            dropdownOptionsContainer.classList.remove('hidden');
            modalForm.querySelector('#field-options').value = field.options.join('\n');
        } else {
            dropdownOptionsContainer.classList.add('hidden');
        }
        
        modal.classList.remove('hidden');
    };
    
    const closeModal = () => modal.classList.add('hidden');

    // Handle form submission inside the modal
    const handleFormSubmit = async (e) => {
        e.preventDefault();
        // Logic to get data and send POST/PUT request to backend
        // On success, close modal and call fetchFormStructure() to refresh.
        console.log('Form submitted');
        closeModal();
        // Fake a refresh
        setTimeout(fetchFormStructure, 200);
    };
    
    // --- SortableJS Drag-and-Drop Initialization ---
    new Sortable(fieldsListElement, {
        animation: 150,
        handle: '.handle', // Use the grip icon as the drag handle
        onEnd: (evt) => {
            console.log('Drag ended. New order needs to be saved.');
            // Get the new order of field IDs
            const newOrder = [...fieldsListElement.children].map(li => li.dataset.fieldId);
            console.log('New order:', newOrder);
            // Send this newOrder array to a backend endpoint like `PUT /api/forms/booking-form/order`
        }
    });


    // --- Event Listeners ---
    const initializeEventListeners = () => {
        addNewBtn.addEventListener('click', openModalForNew);
        modalCloseBtn.addEventListener('click', closeModal);
        modalForm.addEventListener('submit', handleFormSubmit);

        // Show/hide dropdown options based on selected field type
        fieldTypeSelect.addEventListener('change', () => {
            if (fieldTypeSelect.value === 'select') {
                dropdownOptionsContainer.classList.remove('hidden');
            } else {
                dropdownOptionsContainer.classList.add('hidden');
            }
        });
        
        // Use event delegation for edit/delete buttons
        fieldsListElement.addEventListener('click', (e) => {
            const editBtn = e.target.closest('.edit-btn');
            const deleteBtn = e.target.closest('.delete-btn');
            
            if (editBtn) {
                const fieldId = editBtn.closest('.form-field-item').dataset.fieldId;
                openModalForEdit(fieldId);
            }
            if (deleteBtn) {
                if(confirm('Are you sure you want to delete this field?')) {
                    const fieldId = deleteBtn.closest('.form-field-item').dataset.fieldId;
                    console.log(`Deleting field with ID: ${fieldId}`);
                    // Call API to delete, then refresh with fetchFormStructure()
                }
            }
        });
    };

    // --- Initial Load ---
    fetchFormStructure();
    initializeEventListeners();
});
