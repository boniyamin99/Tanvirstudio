document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const tableBody = document.getElementById('delivery-table-body');
    const modal = document.getElementById('upload-modal');
    const modalCloseBtn = modal.querySelector('.modal-close-btn');
    const modalForm = document.getElementById('modal-upload-form');
    const uploadBookingIdSpan = document.getElementById('upload-booking-id');
    const hiddenBookingIdInput = modalForm.querySelector('#bookingId');

    // --- Core Functions ---

    // Main function to fetch and render bookings ready for delivery
    const fetchDeliveries = async () => {
        console.log('Fetching projects ready for delivery...');
        // In a real app, fetch from `/api/deliveries` or `/api/bookings?status=completed`
        const mockApiResponse = {
            deliveries: [
                { bookingId: 101, clientName: 'Client A', serviceType: 'Mixing', projectStatus: 'completed', deliveryStatus: 'pending_upload' },
                { bookingId: 102, clientName: 'Client B', serviceType: 'Recording', projectStatus: 'completed', deliveryStatus: 'delivered' },
                { bookingId: 104, clientName: 'Client D', serviceType: 'Mastering', projectStatus: 'completed', deliveryStatus: 'pending_upload' },
            ]
        };

        tableBody.innerHTML = ''; // Clear table
        mockApiResponse.deliveries.forEach(item => {
            const row = document.createElement('tr');
            const isDelivered = item.deliveryStatus === 'delivered';

            row.innerHTML = `
                <td>${item.bookingId}</td>
                <td>${item.clientName}</td>
                <td>${item.serviceType}</td>
                <td><span class="status-badge status-completed">${item.projectStatus}</span></td>
                <td><span class="status-badge status-${isDelivered ? 'confirmed' : 'pending'}">${item.deliveryStatus.replace('_', ' ')}</span></td>
                <td class="action-buttons">
                    <button class="btn-secondary btn-sm upload-btn" data-booking-id="${item.bookingId}" ${isDelivered ? 'disabled' : ''}>
                        <i class="fas fa-${isDelivered ? 'check-circle' : 'upload'}"></i> 
                        ${isDelivered ? 'Uploaded' : 'Upload File'}
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    };

    // --- Modal Handling ---
    const openUploadModal = (bookingId) => {
        modalForm.reset();
        uploadBookingIdSpan.textContent = bookingId;
        hiddenBookingIdInput.value = bookingId;
        modal.classList.remove('hidden');
    };

    const closeModal = () => {
        modal.classList.add('hidden');
    };

    // --- Form Submission with File Upload ---
    const handleUploadFormSubmit = async (e) => {
        e.preventDefault();
        const submitButton = modalForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Uploading...';

        const formData = new FormData(modalForm);
        const bookingId = formData.get('bookingId');
        
        try {
            console.log(`Uploading file for booking #${bookingId}...`);
            // This will send a multipart/form-data request to the backend
            // const response = await fetch('/api/deliveries', {
            //     method: 'POST',
            //     body: formData 
            //     // No 'Content-Type' header needed for FormData with fetch
            // });

            // if (!response.ok) {
            //     throw new Error('File upload failed.');
            // }

            // Simulating success
            setTimeout(() => {
                alert('File delivered successfully!');
                closeModal();
                fetchDeliveries(); // Refresh the list
            }, 1500);

        } catch (error) {
            console.error('Delivery error:', error);
            alert('An error occurred during file upload.');
        } finally {
            submitButton.disabled = false;
            submitButton.textContent = 'Upload and Deliver';
        }
    };

    // --- Event Listeners ---
    const initializeEventListeners = () => {
        modalCloseBtn.addEventListener('click', closeModal);
        modal.addEventListener('click', e => {
            if (e.target === modal) closeModal();
        });
        modalForm.addEventListener('submit', handleUploadFormSubmit);

        // Event delegation for upload buttons
        tableBody.addEventListener('click', e => {
            const uploadBtn = e.target.closest('.upload-btn');
            if (uploadBtn) {
                const bookingId = uploadBtn.dataset.bookingId;
                openUploadModal(bookingId);
            }
        });

        // Add listeners for filters and pagination...
    };

    // --- Initial Load ---
    fetchDeliveries();
    initializeEventListeners();
});
