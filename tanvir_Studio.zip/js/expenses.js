document.addEventListener('DOMContentLoaded', () => {
    // State management
    let currentPage = 1;
    let currentFilters = { search: '', category: '', startDate: '', endDate: '' };

    // DOM Elements
    const tableBody = document.getElementById('expenses-table-body');
    const addNewBtn = document.getElementById('add-new-expense-btn');
    const modal = document.getElementById('expense-modal');
    const modalCloseBtn = modal.querySelector('.modal-close-btn');
    const modalForm = document.getElementById('modal-expense-form');

    // Main function to fetch and render expenses
    const fetchAndRenderExpenses = async () => {
        const params = new URLSearchParams({ page: currentPage, limit: 10, ...currentFilters });
        console.log(`Fetching from: /api/expenses?${params.toString()}`);

        // --- Mock Data for Demonstration ---
        const mockApiResponse = {
            expenses: [
                { id: 1, description: 'New Condenser Microphone', category: 'equipment', amount: 25000, expenseDate: '2025-05-20', receiptUrl: '#' },
                { id: 2, description: 'Monthly Studio Rent', category: 'studio_rent', amount: 30000, expenseDate: '2025-05-01', receiptUrl: null },
                { id: 3, description: 'Facebook Ad Campaign', category: 'marketing', amount: 5000, expenseDate: '2025-04-25', receiptUrl: '#' },
            ],
            totalPages: 3,
            currentPage: currentPage
        };
        // --- End Mock Data ---

        tableBody.innerHTML = '';
        mockApiResponse.expenses.forEach(expense => {
            const row = document.createElement('tr');
            row.dataset.expenseId = expense.id;
            
            row.innerHTML = `
                <td>EXP-${String(expense.id).padStart(2, '0')}</td>
                <td>${expense.description}</td>
                <td>${expense.category.replace('_', ' ')}</td>
                <td>${expense.amount.toLocaleString()}</td>
                <td>${new Date(expense.expenseDate).toLocaleDateString()}</td>
                <td>
                    ${expense.receiptUrl ? `<a href="${expense.receiptUrl}" target="_blank" class="btn-link">View</a>` : 'N/A'}
                </td>
                <td class="action-buttons">
                    <button class="btn-icon btn-danger delete-btn" title="Delete"><i class="fas fa-trash"></i></button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        // Update pagination and other controls as needed
    };

    // --- Modal Handling ---
    const openModal = () => {
        modalForm.reset();
        modal.classList.remove('hidden');
    };
    const closeModal = () => {
        modal.classList.add('hidden');
    };

    // --- Form Submission with File Upload ---
    const handleFormSubmit = async (e) => {
        e.preventDefault();
        const submitButton = modalForm.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.textContent = 'Saving...';

        // Use FormData to handle multipart/form-data, including files
        const formData = new FormData(modalForm);

        try {
            console.log('Submitting expense form with file...');
            // In a real app, you would fetch('/api/expenses', { method: 'POST', body: formData });
            // Note: Don't set 'Content-Type' header, the browser does it automatically for FormData
            
            // Simulating success
            setTimeout(() => {
                 alert('Expense saved successfully!');
                 closeModal();
                 fetchAndRenderExpenses(); // Refresh the table
                 submitButton.disabled = false;
                 submitButton.textContent = 'Save Expense';
            }, 1000);

        } catch (error) {
            alert('An error occurred while saving the expense.');
            submitButton.disabled = false;
            submitButton.textContent = 'Save Expense';
        }
    };

    // --- Event Listeners Setup ---
    const initializeEventListeners = () => {
        addNewBtn.addEventListener('click', openModal);
        modalCloseBtn.addEventListener('click', closeModal);
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
        modalForm.addEventListener('submit', handleFormSubmit);

        // Add listeners for filters and pagination...
    };

    // --- Initial Load ---
    fetchAndRenderExpenses();
    initializeEventListeners();
});
